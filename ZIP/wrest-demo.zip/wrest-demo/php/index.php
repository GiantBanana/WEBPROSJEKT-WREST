<!DOCTYPE html>
<?php
  $wrestRaw = "";
	$wrest = array();
  foreach(getallheaders() as $name => $value){
  	if($name == "Wrest"){
      $GLOBALS['wrestRaw'] = $value;
  	}
  }
  $wrest = json_decode($wrestRaw, true);
 ?>
<html>
<head>
  <title><?php echo "Wrest blog";?></title>
  <?php
  if($wrest['plainText'] == "on"){
      ?>
      <link rel="stylesheet" type="text/css" href="../css/main-style-simplelang.css">
      <?php
  }else{
    if($wrest['highcontrast'] == "on"){
        ?>
        <link rel="stylesheet" type="text/css" href="../css/main-style-highcontrast.css">
        <?php
    }else{
        ?>
        <link rel="stylesheet" type="text/css" href="../css/main-style.css">
        <?php
    }
  }

?>

  <meta charset="utf-8">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
  </head>
  <body>
    <div id="wrapper_standard">
    <div id="wrapper_contrast">
    	<header>
    		<img src="../images/headerimage.jpeg" class="headerimage" alt="An image featuring
    		several items: mug with pencils, book for writing, a phone. Meant to
    		illustrate the purpose of a blog.">
    		<!-- IMAGE FROM: https://unsplash.com/search/blog?photo=D2quiJA2H-I -->
    	</header>
    	<div id="menu">
    		<ul>
    			<li><a href="index.php">Home</a></li
    			><li><a href="demo-about.php">About the Demo</a></li
    			><li><a href="https://www.w3.org/WAI/intro/wcag.php">WCAG 2.0</a></li
    			><li><a href="#">wREST Main site</a></li
    			><li><a href="demo-links.php">Links</a></li>
    		</ul>
    	</div>
    	<main>
    		<div class="blog_complex">
    			<h2>Principle 1: Perceivable - Information and user interface components must be presentable to users in ways they can perceive.</h2>
    			<div class="timestamp">10.10.2010</div>
    			<div class="entry">
    				<h3>Guideline 1.1 Text Alternatives: Provide text alternatives for any non-text content so that it can be changed into other forms people need, such as large print, braille, speech, symbols or simpler language.</h3>
    				<h4>1.1.1 Non-text Content: All non-text content that is presented to the user has a text alternative that serves the equivalent purpose, except for the situations listed below. (Level A)</h4>
    					<p>
    						<strong>Controls, Input:</strong> If non-text content is a control or accepts user input, then it has a name that describes its purpose. (Refer to Guideline 4.1 for additional requirements for controls and content that accepts user input.)
    					</p>
    					<p>
    						<strong>Time-Based Media:</strong> If non-text content is time-based media, then text alternatives at least provide descriptive identification of the non-text content. (Refer to Guideline 1.2 for additional requirements for media.)</p>
    					<p>
    						<strong>Test:</strong> If non-text content is a test or exercise that would be invalid if presented in text, then text alternatives at least provide descriptive identification of the non-text content.</p>
    					<p>
    						<strong>Sensory:</strong> If non-text content is primarily intended to create a specific sensory experience, then text alternatives at least provide descriptive identification of the non-text content.</p>
    					<p>
    						<strong>CAPTCHA:</strong> If the purpose of non-text content is to confirm that content is being accessed by a person rather than a computer, then text alternatives that identify and describe the purpose of the non-text content are provided, and alternative forms of CAPTCHA using output modes for different types of sensory perception are provided to accommodate different disabilities.</p>
    					<p>
    						<strong>Decoration, Formatting, Invisible:</strong> If non-text content is pure decoration, is used only for visual formatting, or is not presented to users, then it is implemented in a way that it can be ignored by assistive technology.</p>
    				<h3>Guideline 1.2 Time-based Media: Provide alternatives for time-based media.</h3>
    				<h4>1.2.1 Audio-only and Video-only (Prerecorded): For prerecorded audio-only and prerecorded video-only media, the following are true, except when the audio or video is a media alternative for text and is clearly labeled as such: (Level A)</h4>
    				<p>
    					<strong>Prerecorded Audio-only:</strong> An alternative for time-based media is provided that presents equivalent information for prerecorded audio-only content.
    				</p>
    				<p>
    					<strong>Prerecorded Video-only:</strong> Either an alternative for time-based media or an audio track is provided that presents equivalent information for prerecorded video-only content.
    				</p>
    				<h4>1.2.2 Captions (Prerecorded): Captions are provided for all prerecorded audio content in synchronized media, except when the media is a media alternative for text and is clearly labeled as such. (Level A)</h4> <br />
    				<h4>1.2.3 Audio Description or Media Alternative (Prerecorded): An alternative for time-based media or audio description of the prerecorded video content is provided for synchronized media, except when the media is a media alternative for text and is clearly labeled as such. (Level A)</h4>
    				<h4>1.2.4 Captions (Live): Captions are provided for all live audio content in synchronized media. (Level AA)</h4><br />
    				<h4>1.2.5 Audio Description (Prerecorded): Audio description is provided for all prerecorded video content in synchronized media. (Level AA)</h4><br/>
    				<h4>1.2.6 Sign Language (Prerecorded): Sign language interpretation is provided for all prerecorded audio content in synchronized media. (Level AAA)</h4><br/>
    				<h4>1.2.7 Extended Audio Description (Prerecorded): Where pauses in foreground audio are insufficient to allow audio descriptions to convey the sense of the video, extended audio description is provided for all prerecorded video content in synchronized media. (Level AAA)</h4><br/>
    				<h4>1.2.8 Media Alternative (Prerecorded): An alternative for time-based media is provided for all prerecorded synchronized media and for all prerecorded video-only media. (Level AAA)</h4><br/>
    				<h4>1.2.9 Audio-only (Live): An alternative for time-based media that presents equivalent information for live audio-only content is provided. (Level AAA)</h4><br/>

    				<a href="https://www.w3.org/TR/WCAG20/">Click here to read the full WCAG 2.0 at the WCAG Website</a>.<br/>
    			</div>
    		</div>

    		<div class="blog_simple">
    			<h2>The Ten Web Accessbility Commandments</h2>
    			<div class="timestamp">10.10.2010</div>
    			<div class="entry">
    				<h3>1: Readability</h3>
    					<p>Make the entire site readable. Think about things like how your
    						font-to-background contrast ratio might feel to read, the font size and things
    						like spacing between text and the order of items on your site.
    						This also includes making it readable for screenreaders.<br/>
    						<a href="http://webaim.org/techniques/screenreader/">Click here for more info on how to code for screenreaders on WebAIM</a>.</p>

    						<p>The recommended contrast ratio for readability is a ratio of text-color-to-background-color
    						at 4.5:1 on normal text, but preferably you should actually be as high as 7:1.
    						To check your contrast ratio can use a contrast checker, like for example these two links: <br/>
    						- <a href="http://leaverou.github.io/contrast-ratio/">Leaverou.Github.Io</a> <br/>
    						- <a href="http://webaim.org/resources/contrastchecker/">WebAIM Resources</a> <br/> </p>

    						<p>And finally: don't use color as the only way to
    						distinguish things on your site (e.g. links - should always
    						have an underline or another way to identify that they're
    						clickable). A good tip is to set your site to greyscale and
    						see if everything is still readable and easily
    						understandable.</p>

    				<h3>2: Simplicity</h3>
    					<p>
    						Keep it simple. You may want fancy gifs and shiny rainbows
    						on your site, but most of the time it doesn't serve an
    						actual purpose. Cut anything that doesn't make the site
    						more clear and usable, including things that you think
    						might make it funnier and hipper.
    					</p>
    					<p>
    						This also goes for your actual content - simple English goes a
    						long way. Unless your website is specifically academic, why
    						use unnessicarily heavy language?
    					</p>
    				<h3>3: Consistency</h3>
    					<p>
    						If you have more than one page on your website, make sure it
    						looks consistent between each page. Don't have headers that
    						move from the top left of the page to the top right of the
    						page between different sections, that the website doesn't
    						change drastically between pages and is otherwise consistent
    						and easy to understand. Keep the menu and everything clickable
    						working the same and looking alike.
    					</p>
    				<h3>4: Stabiliy</h3>
    					<p>
    						Make sure your website is coded well and works on all screens,
    						browsers and devices, or at least the most common ones. Also
    						make sure your code can be properly validated, this includes
    						closing all tags and making sure you're using them correctly. <br/>
    						<a href="http://validator.w3.org/">Click here to open a validator you can use to check your code.</a> <br/>
    					</p>
    				<h3>5: Silence</h3>
    					<p>
    						The WCAG says you should be able to easily find and pause
    						any audio that plays automatically, but let's be real:
    						Autoplaying is annoying. Just don't do it. This includes
    						visual noise like autoplaying videos and, let's just repeat
    						it again: unnecessary gifs and animations. Let your visitors
    						decide if they want to view or listen to something and make
    						a big PLAY button instead of a big PAUSE button.
    					</p>
    				<h3>6: Descriptive</h3>
    					<p>
    						Having good descriptions on things is good practice in general.
    						Make sure users know what they're going to when they click a link
    						and that each section's header actually describe what said section
    						is going to be about. Make sure it's clear what you're asking for in
    						your forms.  Also: if you're opening a link in a new page or tab, give
    						a warning beforehand that it will open in a new page.
    					</p>
    					<p>
    						Describe images for people who can't see them, using alt texts in HTML.
    						Be consise and clear in the descriptions. Don't use images instead of text
    						when you can avoid it, e.g. for headers and similar; logos are fine, but it
    						should be avoided for paragraphs and links and similar. If you have forms
    						for the users to fill out, be sure to describe how the input should be
    						formatted and let the users know about any errors that might occur
    						(e.g. someone typing in letters in a phone number field).
    					</p>
    				<h3>7: Usability</h3>
    					<p>
    						Make your website easy and intuitive to use. Ties into simplicity, but taken
    						further: Make sure your content is easy to get to, for example by making it
    						possible to skip header sections if it takes a while to scroll past. It's also
    						important to have it be usable for people with different input modes, like
    						for example: all content on your site should be accessible via keyboard.
    					</p>
    				<h3>8: Adaptability</h3>
    					<p>
    						Make sure your text is zoomeable with just the browser's
    						zoom function (or add a text size option). If you have a
    						site with a time limit, it should be possible to turn it
    						off or adapt it, unless it's connected to a real world
    						event (like an auction) or if it's essential to the content
    						(like a quiz).
    					</p>
    				<h3>9: Security</h3>
    					<p>
    						Make sure if you have users give any form of input, like
    						important forms (e.g. legal or financial forms), that they
    						can double check the info before submitting them. The info
    						should also, obviously, be transferred and stored securely.
    					</p>
    				<h3>10: Inclusivity</h3>
    					<p>
    						10. This last rule is perhaps the most important one, but it's
    						basically just a summary of all of the other rules: Try to
    						make sure your website is inclusive of different kinds of
    						users. Think about other people's situations and try, to
    						the best of your abilities, to figure out what they might
    						need from your site.
    					</p>

    				<a href="https://www.w3.org/TR/WCAG20/">Adapted from the Web Content Accessbility Guidelines 2.0.</a>
    			</div>
    		</div>
    	</main>
    	<footer>
    		<a href="">Click here to return to the wREST main site.</a>
    	</footer>
    </div>
    </div>
    </body>
    </html>

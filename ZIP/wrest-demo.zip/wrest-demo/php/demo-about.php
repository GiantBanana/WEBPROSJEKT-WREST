<!DOCTYPE html>
<?php
  $wrestRaw = "";
	$wrest = array();
  foreach(getallheaders() as $name => $value){
  	if($name == "Wrest"){
      $GLOBALS['wrestRaw'] = $value;
  	}
  }
  $wrest = json_decode($wrestRaw, true);
 ?>
<html>
<head>
	<title>WREST-blog</title>
  <?php
if($wrest['highcontrast'] == "on"){
    ?>
    <link rel="stylesheet" type="text/css" href="../css/main-style-highcontrast.css">
    <?php
}else{
    ?>
    <link rel="stylesheet" type="text/css" href="../css/main-style.css">
    <?php
}?>
	<meta charset="utf-8">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
</head>
<body>
<div id="wrapper_standard">
<div id="wrapper_contrast">
	<header>
		<img src="../images/headerimage.jpeg" alt="An image featuring
		several items: mug with pencils, book for writing, a phone. Meant to
		illustrate the purpose of a blog.">
		<!-- IMAGE FROM: https://unsplash.com/search/blog?photo=D2quiJA2H-I -->
	</header>
	<div id="menu">
		<ul>
			<li><a href="index.php">Home</a></li
			><li><a href="demo-about.php">About the Demo</a></li
			><li><a href="https://www.w3.org/WAI/intro/wcag.php">WCAG 2.0</a></li
			><li><a href="#">WREST Main Site</a></li
			><li><a href="demo-links.php">Links</a></li>
		</ul>
	</div>
	<main>
		<div class="blog_complex">
			<h2>About this demo site</h2>
			<div class="timestamp">10.10.2010</div>
			<div class="entry">
				<p>Welcome to the wREST demo site, where we demonstrate our
				prototype. Test it out on this page and then download the CSS
				if you need inspiration on how to implement it on your own website.
				For more information about wREST, the extention and more, visit our
				main site. Thanks!</p>
			</div>
		</div>

		<div class="blog_simple">
		<h2>About the demo site</h2>
		<div class="timestamp">10.10.2010</div>
			<div class="entry">
				<p>Welcome to the wREST demo site. Here you can test how the
				Google Chrome extention can change a website, and also download the
				CSS file if you'd like to try it out on your own.
				For more information, please visit our main site. Thanks!</p>
			</div>
	</main>
	<footer>
		<a href="">Click here to return to the wREST main site.</a>
	</footer>
</div>
</div>
</body>
</html>

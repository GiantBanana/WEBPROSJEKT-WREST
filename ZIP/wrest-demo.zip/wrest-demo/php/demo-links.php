<!DOCTYPE html>
<?php
  $wrestRaw = "";
	$wrest = array();
  foreach(getallheaders() as $name => $value){
  	if($name == "Wrest"){
      $GLOBALS['wrestRaw'] = $value;
  	}
  }
  $wrest = json_decode($wrestRaw, true);
 ?>
<html>
<head>
  <title><?php echo "Wrest blog";?></title>
  <?php
if($wrest['highcontrast'] == "on"){
    ?>
    <link rel="stylesheet" type="text/css" href="../css/main-style-highcontrast.css">
    <?php
}else{
    ?>
    <link rel="stylesheet" type="text/css" href="../css/main-style.css">
    <?php
}?>
	<meta charset="utf-8">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
</head>
<body>
<div id="wrapper">
	<header>
		<img src="../images/headerimage.jpeg" alt="An image featuring
		several items: mug with pencils, book for writing, a phone. Meant to
		illustrate the purpose of a blog.">
		<!-- IMAGE FROM: https://unsplash.com/search/blog?photo=D2quiJA2H-I -->
	</header>
	<div id="menu">
		<ul>
			<li><a href="index.php">Home</a></li
			><li><a href="demo-about.php">About the Demo</a></li
			><li><a href="https://www.w3.org/WAI/intro/wcag.php">WCAG 2.0</a></li
			><li><a href="#">WREST Main Site</a></li
			><li><a href="demo-links.php">Links</a></li>
		</ul>
	</div>
	<main>
		<div class="blog_complex">
			<h2>Other Useful Links</h2>
			<div class="timestamp">10.10.2010</div>
			<div class="entry">
				<h3>About Accesibility:</h3>
				<p>
				<ul>
					<li><a href="http://www.afb.org/info/living-with-vision-loss/using-technology/creating-accessible-websites/123">American Foundation for the Blind</a></li>
					<li><a href="https://accessibility.blog.gov.uk/2016/09/02/dos-and-donts-on-designing-for-accessibility/">GOV.uk: Dos and Don'ts on Designing for Accesibility</a></li>
					<li><a href="http://alistapart.com/article/tohellwithwcag2">To Hell With WCAG 2.0</a></li>
					<li><a href="http://juicystudio.com/experiments/invalid.html">Inaccessible Content: A What Not To Do</a></li>
					<li><a href="https://www.dyslexic.com/fonts/">Typefaces for Dyslexia</a></li>
					<li><a href="https://bdatech.org/what-technology/typefaces-for-dyslexia/">Typefaces for Dyslexia</a></li>
					<li><a href="http://webaim.org/techniques/alttext/">Web Accesibility in Mind: Alt Text</a></li>
					<li><a href="http://webaim.org/techniques/css/invisiblecontent/">Web Accesibility in Mind: CSS in Action/Invisible Content</a></li>
					<li><a href="http://webaim.org/resources/contrastchecker/">Web Accesibility in Mind: Contrast Checker</a></li>
					<li><a href="http://webaim.org/techniques/screenreader/">Web Accesibility in Mind: Coding for Screen Readers</a></li>
					<li><a href="http://libux.co/links-should-open-in-the-same-window/">Links Should Open in the Same Window</a></li>
				</ul>
				</p>
				<p>
				<h3>About Design:</h3>
				<ul>
					<li><a href="http://sixrevisions.com/usabilityaccessibility/improving-usability-with-fitts-law/">Improving Usability with Fitt's Law</a></li>
					<li><a href="https://www.nngroup.com/articles/centered-logos/">Centered Logos Hurt Website Navigation</a></li>
					<li><a href="http://alistapart.com/article/responsive-web-design">Responsive Web Design</a></li>
					<li><a href="https://www.distilled.net/training/mobile-seo-guide/">Building Your Mobile-Friendly Site</a></li>
					<li><a href="http://www.websitebuilderexpert.com/how-to-choose-color-for-your-website/">How to Choose a Good Color Scheme for your Website</a></li>
					<li><a href=""></a></li>
				</ul>
				</p>
			</div>
		</div>

		<div class="blog_simple">
		<h2>Other Useful Links</h2>
		<div class="timestamp">10.10.2010</div>
			<div class="entry">
				<h3>About Accesibility:</h3>
				<ul>
					<li><a href="http://www.afb.org/info/living-with-vision-loss/using-technology/creating-accessible-websites/123">American Foundation for the Blind</a></li>
					<li><a href="https://accessibility.blog.gov.uk/2016/09/02/dos-and-donts-on-designing-for-accessibility/">GOV.uk: Dos and Don'ts on Designing for Accesibility</a></li>
					<li><a href="http://alistapart.com/article/tohellwithwcag2">To Hell With WCAG 2.0</a></li>
					<li><a href="http://juicystudio.com/experiments/invalid.html">Inaccessible Content: A What Not To Do</a></li>
					<li><a href="https://www.dyslexic.com/fonts/">Typefaces for Dyslexia</a></li>
					<li><a href="https://bdatech.org/what-technology/typefaces-for-dyslexia/">Typefaces for Dyslexia</a></li>
					<li><a href="http://webaim.org/techniques/alttext/">Web Accesibility in Mind: Alt Text</a></li>
					<li><a href="http://webaim.org/techniques/css/invisiblecontent/">Web Accesibility in Mind: CSS in Action/Invisible Content</a></li>
					<li><a href="http://webaim.org/resources/contrastchecker/">Web Accesibility in Mind: Contrast Checker</a></li>
					<li><a href="http://webaim.org/techniques/screenreader/">Web Accesibility in Mind: Coding for Screen Readers</a></li>
					<li><a href="http://libux.co/links-should-open-in-the-same-window/">Links Should Open in the Same Window</a></li>
				</ul>

				<h3>About Design:</h3>
				<ul>
					<li><a href="http://sixrevisions.com/usabilityaccessibility/improving-usability-with-fitts-law/">Improving Usability with Fitt's Law</a></li>
					<li><a href="https://www.nngroup.com/articles/centered-logos/">Centered Logos Hurt Website Navigation</a></li>
					<li><a href="http://alistapart.com/article/responsive-web-design">Responsive Web Design</a></li>
					<li><a href="https://www.distilled.net/training/mobile-seo-guide/">Building Your Mobile-Friendly Site</a></li>
					<li><a href="http://www.websitebuilderexpert.com/how-to-choose-color-for-your-website/">How to Choose a Good Color Scheme for your Website</a></li>
					<li><a href=""></a></li>
				</ul>
			</div>
	</main>
	<footer>
		<a href="">Click here to return to the wREST main site.</a>
	</footer>
</div>
</body>
</html>
